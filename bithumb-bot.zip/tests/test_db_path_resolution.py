from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from bithumb_bot import config
import pytest

from bithumb_bot.db import connect
from bithumb_bot.db_core import ensure_db


def test_relative_db_path_is_rejected() -> None:
    with pytest.raises(ValueError) as exc:
        config.resolve_db_path("data/test.sqlite")
    assert "DB_PATH must be an absolute path" in str(exc.value)


def test_absolute_db_path_is_preserved(tmp_path, monkeypatch):
    project_root = tmp_path / "project"
    project_root.mkdir()
    monkeypatch.setattr(config, "PROJECT_ROOT", project_root)

    absolute_db_path = tmp_path / "abs" / "absolute.sqlite"
    conn = ensure_db(str(absolute_db_path))
    conn.close()

    assert absolute_db_path.exists()


def test_connect_rejects_relative_paths() -> None:
    with pytest.raises(ValueError):
        connect("data/test.sqlite")


def test_connect_does_not_create_parent_directory_directly(tmp_path: Path) -> None:
    db_path = (tmp_path / "managed" / "centralized.sqlite").resolve()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    with (
        patch("bithumb_bot.db.prepare_db_path_for_connection", return_value=str(db_path)),
        patch("pathlib.Path.mkdir", side_effect=AssertionError("db connect layer must not mkdir")),
    ):
        conn = connect(str(db_path))
    conn.close()


def test_ensure_db_does_not_create_parent_directory_directly(tmp_path: Path) -> None:
    db_path = (tmp_path / "managed" / "centralized.sqlite").resolve()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    with (
        patch("bithumb_bot.db_core.prepare_db_path_for_connection", return_value=str(db_path)),
        patch("pathlib.Path.mkdir", side_effect=AssertionError("db open layer must not mkdir")),
    ):
        conn = ensure_db(str(db_path))
    conn.close()


def test_resolve_db_path_for_connection_does_not_prepare_parent(tmp_path: Path) -> None:
    db_path = (tmp_path / "managed" / "resolve-only.sqlite").resolve()
    with patch("pathlib.Path.mkdir", side_effect=AssertionError("resolve helper must not mkdir")):
        resolved = config.resolve_db_path_for_connection(str(db_path), mode="paper")
    assert resolved == str(db_path)
    assert not db_path.parent.exists()


def test_prepare_db_path_for_connection_prepares_parent_with_path_manager(tmp_path: Path) -> None:
    db_path = (tmp_path / "managed" / "prepared.sqlite").resolve()
    with patch.object(type(config.PATH_MANAGER), "ensure_parent_dir") as ensure_parent_dir:
        resolved = config.prepare_db_path_for_connection(str(db_path), mode="paper")
    assert resolved == str(db_path)
    ensure_parent_dir.assert_called_once_with(Path(resolved))


def test_settings_db_path_accepts_absolute_path(tmp_path):
    old_db_path = config.settings.DB_PATH
    db_path = (tmp_path / "managed" / "test.sqlite").resolve()
    object.__setattr__(config.settings, "DB_PATH", str(db_path))

    try:
        conn = ensure_db()
        conn.close()
    finally:
        object.__setattr__(config.settings, "DB_PATH", old_db_path)

    assert db_path.exists()


def test_live_db_path_rejects_paper_scoped_override(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("MODE", "live")
    with pytest.raises(config.LiveModeValidationError) as exc:
        config.resolve_db_path_for_mode(str((tmp_path / "runtime" / "paper" / "live.sqlite").resolve()), mode="live")
    assert "paper-scoped path" in str(exc.value)


def test_relative_run_lock_path_is_project_root_based(tmp_path, monkeypatch):
    project_root = tmp_path / "project"
    project_root.mkdir()
    monkeypatch.setattr(config, "PROJECT_ROOT", project_root)

    resolved = config.resolve_run_lock_path("run/paper/instance-a.lock")

    assert resolved == str((project_root / "run" / "paper" / "instance-a.lock").resolve())


def test_default_run_lock_path_is_mode_scoped():
    paper_lock = config.default_run_lock_path("paper")
    live_lock = config.default_run_lock_path("live")
    assert "/paper/" in paper_lock.replace("\\", "/")
    assert "/live/" in live_lock.replace("\\", "/")


def test_live_run_lock_path_rejects_relative_override() -> None:
    with pytest.raises(ValueError) as exc:
        config.resolve_run_lock_path("run/live/instance-a.lock", mode="live")
    assert "RUN_LOCK_PATH must be an absolute path when MODE=live" in str(exc.value)
